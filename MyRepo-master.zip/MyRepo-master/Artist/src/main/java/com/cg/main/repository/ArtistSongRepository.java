package com.cg.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.main.entities.Artist_Song;
import com.cg.main.entities.Composer;

public interface ArtistSongRepository extends JpaRepository<Artist_Song,Integer>{

}
