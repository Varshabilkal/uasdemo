package com.cg.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.main.entities.MusicSociety;

public interface MusicSocietyRepository extends JpaRepository<MusicSociety,String>  {

}
