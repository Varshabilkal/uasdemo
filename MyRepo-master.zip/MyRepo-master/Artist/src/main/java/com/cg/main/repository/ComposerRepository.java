package com.cg.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.main.entities.Composer;


public interface ComposerRepository extends JpaRepository<Composer,Integer> {

}
